import {Fragment} from 'react';
import {Button,Card} from '@heroui/react';
import {NavLink} from 'react-router';
import logo from '../../assets/hala-logo.png';
import {navigation} from '../../config/navigation';
import {Icon,colors} from '../ui/Icon';

export function Sidebar({onNavigate,onHelp}){
  return <>
    <NavLink to="/" onClick={onNavigate} className="brand" aria-label="هلا كوميرس — الرئيسية"><span className="logo-crop"><img src={logo} alt="Hala kommers"/></span></NavLink>
    <nav className="side-nav" aria-label="أقسام هلا">
      <p className="nav-caption">إدارة المتجر</p>
      {navigation.map(({icon,label,path},index)=><Fragment key={label}>{index===8?<p className="nav-caption nav-caption-tools">أدوات الحساب</p>:null}{path?<NavLink end to={path} key={label} onClick={onNavigate} className={({isActive})=>'side-link '+(isActive?'current':'')}>
        {({isActive})=><><Icon name={icon} color={isActive?colors.purple:undefined}/><span>{label}</span></>}
      </NavLink>:<span className="side-link static" key={label}><Icon name={icon}/><span>{label}</span></span>}</Fragment>)}
    </nav>
    <Card className="help-card" variant="secondary"><Icon name="headset" color={colors.purple}/><h3>محتاج مساعدة؟</h3><p>فريق هلا جاهز لمساعدتك<br/>والإجابة على استفساراتك</p><Button size="sm" onPress={onHelp}>تواصل الآن</Button></Card>
  </>;
}
