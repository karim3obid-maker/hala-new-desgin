import {DashboardFilters} from '../components/dashboard/DashboardFilters';
import {PeriodBoundary} from '../components/dashboard/PeriodBoundary';
import {ShipmentsSummary} from '../components/dashboard/Summaries';

export default function ShipmentsPage(){return <><DashboardFilters/><PeriodBoundary><ShipmentsSummary/></PeriodBoundary></>}
