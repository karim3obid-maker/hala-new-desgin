import {Card} from '@heroui/react';
import {DashboardFilters} from '../components/dashboard/DashboardFilters';
import {PeriodBoundary} from '../components/dashboard/PeriodBoundary';
import {OrdersSummary} from '../components/dashboard/Summaries';

export default function OrdersPage(){
  return <><DashboardFilters/><PeriodBoundary>
    <OrdersSummary/>
    <Card className="records-state" role="status"><h2>قائمة الطلبات</h2><p>تفاصيل الطلبات غير متاحة حاليًا. يمكنك متابعة إجمالي الطلبات وحالاتها من الإحصائيات أعلاه.</p></Card>
  </PeriodBoundary></>;
}
