import {DashboardFilters} from '../components/dashboard/DashboardFilters';
import {PeriodBoundary} from '../components/dashboard/PeriodBoundary';
import {FinancialSummary} from '../components/dashboard/Summaries';

export default function WalletPage(){return <><DashboardFilters/><PeriodBoundary><FinancialSummary/></PeriodBoundary></>}
