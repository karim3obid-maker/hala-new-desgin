export const navigation=[
  {icon:'layout-grid',label:'الرئيسية',path:'/'},
  {icon:'currency-dollar',label:'الأفلييت'},
  {icon:'package',label:'المنتجات'},
  {icon:'shopping-cart',label:'الطلبات',path:'/orders'},
  {icon:'truck',label:'الشحنات',path:'/shipments'},
  {icon:'link',label:'التكاملات'},
  {icon:'file-import',label:'طلبات الاستيراد'},
  {icon:'wallet',label:'المحفظة المالية',path:'/wallet'},
  {icon:'calculator',label:'الحاسبة'},
  {icon:'settings',label:'الإعدادات'},
];
export const pageTitles={'/':'لوحة التحكم','/orders':'الطلبات','/shipments':'الشحنات','/wallet':'المحفظة المالية'};
export const metricGroups={orders:{label:'الطلبات',path:'/orders'},shipments:{label:'الشحنات',path:'/shipments'},financial:{label:'المالية',path:'/wallet'}};
