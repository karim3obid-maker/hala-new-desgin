import {I18nProvider} from '@heroui/react';
import {HashRouter,Navigate,Route,Routes} from 'react-router';
import {AdminLayout} from './components/layout/AdminLayout';
import {DashboardProvider} from './context/DashboardContext';
import DashboardPage from './pages/DashboardPage';
import OrdersPage from './pages/OrdersPage';
import ShipmentsPage from './pages/ShipmentsPage';
import WalletPage from './pages/WalletPage';
import NotFoundPage from './pages/NotFoundPage';

export default function App(){
  return <I18nProvider locale="ar-EG"><HashRouter><DashboardProvider>
    <Routes><Route element={<AdminLayout/>}>
      <Route index element={<DashboardPage/>}/>
      <Route path="overview" element={<Navigate to="/" replace/>}/>
      <Route path="orders" element={<OrdersPage/>}/>
      <Route path="shipments" element={<ShipmentsPage/>}/>
      <Route path="wallet" element={<WalletPage/>}/>
      <Route path="financial" element={<Navigate to="/wallet" replace/>}/>
      <Route path="*" element={<NotFoundPage/>}/>
    </Route></Routes>
  </DashboardProvider></HashRouter></I18nProvider>;
}
